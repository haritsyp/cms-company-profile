<?php $__env->startSection('content'); ?>

<section class="about-details-area section-padding wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                <div class="area-title text-center wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
                    <h2>Tentang Kami</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-xs-12">
                <ul class="about-details-menu">
                    <li class="active"><a data-toggle="tab" href="#company">Profil Perusahaan</a></li>
                    <li><a data-toggle="tab" href="#history">Sejarah Kami</a></li>
                    <li><a data-toggle="tab" href="#support">Aktivitas</a></li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                <div class="tab-content about-details-content">
                    <div id="company" class="about-company tab-pane fade in active">
                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                <div class="about-history-content">
                                    <?php echo $profil->isi; ?>

                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                <div class="about-history-content">
                                    <img src="<?php echo e(asset('img/5814.jpg')); ?>" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                <div class="about-history-content">
                                    <h3><?php echo e($visi->header); ?></h3>
                                    <?php echo $visi->isi; ?>

                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                <div class="about-history-content">
                                    <h3><?php echo e($misi->header); ?></h3>
                                    <?php echo $misi->isi; ?>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="history" class="company-history tab-pane fade">
                        <div class="row">
                            <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                <div class="about-history-content">
                                    <?php echo $sejarah->isi; ?>

                                </div>
                            </div>
                            <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                <div class="about-history-content">
                                    <img src="img/about/about-cargo.png" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="support" class="support-content tab-pane fade in">
                        <div class="row">
                            <div class="col-md-8 col-lg-8 col-sm-12 col-xs-12">
                                <?php echo $aktivitas->isi; ?>

                            </div>
                            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                                <div class="promo-img">
                                    <img src="<?php echo e(asset('img/5822.jpg')); ?>" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kpilogistics\resources\views/pages/front/about.blade.php ENDPATH**/ ?>