
<div class="form-group row">
    <label for="name" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>

    <div class="col-md-6">
        <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e($user->name ??  old('name')); ?>" required autocomplete="name" autofocus  <?php if(isset($user->name)): ?> readonly="readonly"  <?php endif; ?>>

        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    </div>
</div>

<div class="form-group row">
    <label for="username" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Username')); ?></label>

    <div class="col-md-6">
        <input id="username" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="username" value="<?php echo e($user->username ?? old('username')); ?>" required autocomplete="username" <?php if(isset($user->username)): ?> readonly="readonly"  <?php endif; ?>>

        <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    </div>
</div>

<div class="form-group row">
    <label for="password" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

    <div class="col-md-6">
        <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">

        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
    </div>
</div>

<div class="form-group row">
    <label for="password-confirm" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

    <div class="col-md-6">
        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
    </div>
</div>

<div class="form-group row mb-0">
    <div class="col-md-6 offset-md-2">
        <button type="submit" class="btn btn-primary">
            <?php echo e(__('Simpan')); ?>

        </button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\kpilogistics\src\resources\views/pages/admin/user/form.blade.php ENDPATH**/ ?>