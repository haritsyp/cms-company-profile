<?php $__env->startSection('content'); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Form <?php echo e($page_attributes->title); ?> </h6>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('kategori.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('pages.admin.kategori.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </form>
  </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kpilogistics\src\resources\views/pages/admin/kategori/add.blade.php ENDPATH**/ ?>