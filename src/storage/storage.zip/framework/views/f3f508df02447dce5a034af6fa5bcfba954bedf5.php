<?php $__env->startSection('content'); ?>

<section class="blog-area blog-page section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-lg-8 col-sm-12 col-xs-12">
                    <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="single-blog wow fadeIn">
                        <div class="blog-image">
                            <img src="<?php echo e(asset('uploads').'/'.$a->gambar); ?>"  alt="" style="height: 400px;object-fit: cover">
                        </div>
                        <div class="blog-details">
                            <div class="blog-meta"><a href="#"><i class="fa fa-truck"></i></a></div>
                            <h3><a  href="<?php echo e(url('blog/read').'/'.$a->id); ?>"><?php echo e($a->judul); ?></a></h3>
                            <div class="post-date"><a href="#"><i class="fa fa-calendar"></i>
                                <?php echo e(date("d F, Y", strtotime($a->tanggal))); ?>

                            </a></div>
                            <p><?php echo substr($a->isi,0,300); ?>}</p>
                            <a style="display: block" href="<?php echo e(url('blog/read').'/'.$a->id); ?>" class="read-more">Read More</a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                    <div class="sidebar-area wow fadeIn">
                        <div class="single-sidebar-widget widget_search">
                            <h4>Cari</h4>
                            <form action="" method="GET">
                                <input type="text" name="judul" id="s" placeholder="Cari Disini...">
                                <button type="submit"><i class="fa fa-search"></i></button>
                            </form>
                        </div>
                        <div class="single-sidebar-widget widget_categories">
                            <h4>Kategori</h4>
                            <ul class="myul">
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(url('blog').'?id_kategori='.$k->id); ?>"><?php echo e($k->nama); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="single-sidebar-widget widget_recent_entries">
                            <h4>Postingan Terbaru</h4>
                            <ul>
                                <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="alignleft"><img style="width: 65px" src="<?php echo e(asset('uploads').'/'.$a->gambar); ?>" alt=""></div>
                                    <a href="<?php echo e(url('blog/read').'/'.$a->id); ?>"><?php echo e($a->judul); ?></a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-xs-12">
                    <?php echo e($artikels->links()); ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kpilogistics\src\resources\views/pages/front/blog.blade.php ENDPATH**/ ?>