<?php 
$imgfile = 'img/dummy.jpg';
if(isset($galeri->gambar) && $galeri->gambar != null){
	$imgfile = 'galeri/'.$galeri->gambar;
}
?>

<div class="row" >
	<div class="col-sm-6">
		<div class="form-group row">
			<label for="colFormLabel" class="col-sm-12 col-form-label">
				Gambar
			</label>
			<div class="col-sm-12">
				<img class="img-cover" src="<?php echo e(asset($imgfile)); ?>" width="100%" id="preview">
			</div>
			<div class="col-sm-12">
				<input type="file" name="gambar" class="form-control file-control" onchange="readURL(this);">
			</div>
		</div>
	</div>
	<div class="col-sm-6">
		<label for="colFormLabel" class="col-sm-12 col-form-label">
			Layanan
		</label>
		<div class="col-sm-12">
			<select class="form-control" id="layanan" name="id_layanan">
				<?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option  value="<?php echo e($d->id); ?>"><?php echo e($d->nama); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		<label for="colFormLabel" class="col-sm-12 col-form-label">
			Deksripsi
		</label>
		<div class="col-sm-12">
			<textarea name="deskripsi" id="editor1" rows="10" cols="80">
				<?php echo e($galeri->deskripsi ?? ''); ?>

			</textarea>
		</div>
	</div>
</div>
<?php /**PATH C:\xampp\htdocs\kpilogistics\src\resources\views/pages/admin/galeri/form.blade.php ENDPATH**/ ?>