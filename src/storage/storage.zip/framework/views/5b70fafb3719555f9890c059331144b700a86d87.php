<?php $__env->startSection('content'); ?>

<section class="blog-area gray-bg section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                <div class="area-title text-center wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
                    <h2>Layanan Kami</h2>
                    <p></p>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                <div class="single-blog wow fadeInUp" data-wow-delay="0.2s">
                    <div class="blog-image" style="height: 240px;" style="object-fit: cover">
                        <center>
                            <img  src="<?php echo e(asset('layanan').'/'.$d->gambar); ?>" alt="" style="height: 240px;object-fit: cover!important; ">
                        </center>
                    </div>
                    <div class="blog-details text-center">
                        <div class="blog-meta"><a href="#"><i class="fa fa-truck"></i></a></div>
                        <h3><a href="single-blog.html"><?php echo e($d->nama); ?></a></h3>
                        <p><?php echo e(substr($d->deskripsi,0,120)); ?>...</p>
                        <a href="<?php echo e(url('service').'/'.$d->id); ?>"  class="read-more">Selengkapnya</a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kpilogistics\resources\views/pages/front/layanan.blade.php ENDPATH**/ ?>