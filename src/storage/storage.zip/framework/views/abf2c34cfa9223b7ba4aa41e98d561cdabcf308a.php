<?php $__env->startSection('content'); ?>

<section class="blog-area blog-page section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="service-menu">
                    <h4>Service Details</h4>
                    <ul>
                        <?php $__currentLoopData = $layananall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(url('service').'/'.$a->id); ?>"><?php echo e($a->nama); ?><i class="fa fa-angle-right"></i></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-9">
                <div class="single-blog wow fadeIn">
                    <div class="blog-image">
                        <img src="<?php echo e(asset('layanan').'/'.$layanans->gambar); ?>"  alt="" style="height: 400px;object-fit: cover">
                    </div>
                    <div class="blog-details">
                        <h3><a href="single-blog.html"><?php echo e($layanans->nama); ?></a></h3>
                        <p><?php echo $layanans->konten; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kpilogistics\resources\views/pages/front/deskripsi.blade.php ENDPATH**/ ?>