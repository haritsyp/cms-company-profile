<?php $__env->startSection('content'); ?>
<section class="blog-area gray-bg">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $layanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($layanan)-$key != 1 ): ?>
            <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                <div class="single-blog wow fadeInUp" data-wow-delay="0.2s">
                    <div class="blog-image" style="height: 240px;" style="object-fit: cover">
                        <center>
                            <img  src="<?php echo e(asset('layanan').'/'.$d->gambar); ?>" alt="" style="height: 240px;object-fit: cover!important; ">
                        </center>
                    </div>
                    <div class="blog-details text-center">
                        <div class="blog-meta"><a href="#"><i class="fa fa-truck"></i></a></div>
                        <h3><a href="single-blog.html"><?php echo e($d->nama); ?></a></h3>
                        <p><?php echo e(substr($d->deskripsi,0,120)); ?>...</p>
                        <a  href="<?php echo e(url('service').'/'.$d->id); ?>" class="read-more">Selengkapnya</a>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                <div class="single-blog wow fadeInUp" data-wow-delay="0.2s">
                    <div class="blog-image">
                        <center>
                            <img  src="<?php echo e(asset('layanan').'/'.$d->gambar); ?>" alt="" style="height: 240px;object-fit: cover!important; ">
                        </center>
                    </div>
                    <div class="blog-details text-center">
                        <div class="blog-meta"><a href="#"><i class="fa fa-truck"></i></a></div>
                        <h3><a href="single-blog.html"><?php echo e($d->nama); ?></a></h3>
                        <p><?php echo e(substr($d->deskripsi,0,120)); ?>...</p>
                        <a  href="<?php echo e(url('service').'/'.$d->id); ?>" class="read-more">Selengkapnya</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!--BLOG AREA END-->

<!--ABOUT AREA-->
<section class="about-area gray-bg section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="about-content-area wow fadeIn">
                    <div class="about-content">
                        <h2><?php echo e($profil->header); ?></h2>
                        <?php echo substr($profil->isi,0,347); ?>...
                        <a href="<?php echo e(url('about')); ?>" style="display: block;">selengkapnya <i class="fa fa-angle-right"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-5">
               <img src="<?php echo e(asset('img/5814.jpg')); ?>" style="border-radius:4px;object-fit: fill">
            </div>
        </div>
    </div>
</section>
<!--ABOUT AREA END-->

<section class="team-aera section-padding gray-bg">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                <div class="area-title text-center wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
                    <h2 style="text-transform: unset;">Blog Terbaru</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(count($artikel)-$key != 1 ): ?>
            <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                <div class="single-team" style="background-color: white;">
                    <div class="member-image">
                        <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($a->gambar); ?>" style="object-fit: cover; height: 250px" >
                    </div>
                    <div class="member-details"s>
                        <h6 class="text-left"><?php echo e(substr($a->judul,0,45)); ?></h6>
                        <p class="text-left">
                             <a  href="<?php echo e(url('blog/read').'/'.$a->id); ?>" style="display: block;">selengkapnya <i class="fa fa-angle-right"></i></a>
                        </p>
                    </div>
                </div>
            </div>
            <?php else: ?>
             <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                <div class="single-team" style="background-color: white;">
                    <div class="member-image">
                        <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($a->gambar); ?>" style="object-fit: cover; height: 250px">
                    </div>
                    <div class="member-details"s>
                        <h6 class="text-left"><?php echo e(substr($a->judul,0,45)); ?></h6>
                        <p class="text-left">
                             <a href="<?php echo e(url('blog/read').'/'.$a->id); ?>" style="display: block;">selengkapnya <i class="fa fa-angle-right"></i></a>
                        </p>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!--CLIENTS AREA-->
<section class="clients-area section-padding gray-bg wow fadeIn">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                <div class="area-title text-center wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
                    <h2 style="text-transform: unset;">Partner</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                <div class="client-list">
                    <?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="single-client">
                        <img src="<?php echo e(asset('partner')); ?>/<?php echo e($p->gambar); ?>" alt="" style="height: 80px;">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kpilogistics\resources\views/pages/front/index.blade.php ENDPATH**/ ?>