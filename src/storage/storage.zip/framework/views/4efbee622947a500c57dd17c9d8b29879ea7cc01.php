<?php $__env->startSection('content'); ?>
<section class="contact-area" id="contact">
    <div class="contact-form-area section-padding gray-bg">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                    <div class="area-title text-center">
                        <h3>KONTAK</h3>
                        <p>Hubungi kami melalui nomor telepon atau email dibawah ini</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="contact-image">
                        <center>
                            <div class="contact-address">
                                <h4>Alamat</h4>
                                <p>Telepon 1: <a href="callto:<?php echo e($konfigurasi->telp1); ?>"><?php echo e($konfigurasi->telp1); ?></a></p>
                                <p>Telepon 2: <a href="callto:<?php echo e($konfigurasi->telp2); ?>"><?php echo e($konfigurasi->telp2); ?></a></p>
                                <p>Email: <a href="mailto:<?php echo e($konfigurasi->emaik); ?>"><?php echo e($konfigurasi->email); ?></a></p>
                                <address>
                                    Kantor  :  <?php echo e($konfigurasi->alamat); ?>

                                </address>
                            </div>
                            <div class="social-bookmark">
                                <h4>Kunjungi Kami </h4>
                                <ul>
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                    <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                </ul>
                            </div>
                        </center>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kpilogistics\src\resources\views/pages/front/kontak.blade.php ENDPATH**/ ?>