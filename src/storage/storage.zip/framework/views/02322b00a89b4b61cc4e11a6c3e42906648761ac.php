<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('theme.css')); ?>" rel="stylesheet">
<style type="text/css">
    body.modal-open {
        overflow: visible;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="blog-area gray-bg section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-lg-6 col-md-offset-3 col-lg-offset-3 col-sm-12 col-xs-12">
                <div class="area-title text-center wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
                    <h2>Galeri Kami</h2>
                    <p></p>
                </div>
            </div>
        </div>
        <div class="row">
         <section class="content-with-menu-has-toolbar media-gallery">
            <div class="row mg-files" data-sort-destination="" data-sort-id="media-gallery">
                <?php $__currentLoopData = $id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <center><h4><?php echo e($i->nama); ?></h4></center>
                    <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($i->id_layanan == $g->id_layanan): ?>

                    <div class="isotope-item document col-sm-6 col-md-4 col-lg-3">
                        <div class="thumbnail">
                            <div class="thumb-preview">
                                <a class="thumb-image" href="<?php echo e(asset('galeri/'.$g->gambar)); ?>">
                                    <img src="<?php echo e(asset('galeri/'.$g->gambar)); ?>" style="height: 200px;object-fit: cover">
                                </a>
                                <div class="mg-thumb-options">
                                    <div class="mg-zoom" data-id="<?php echo e($g->id); ?>" style="font-size: 12px;background-color: #4e73df;opacity: 0.8">
                                        <i class="fa fa-search"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
</div>
</section>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document" style="width:900px;max-width: 900px;padding: 30px;max-height: auto">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-8">
                        <img id="imgzoom" style="width: 100%">
                    </div>
                    <div class="col-md-4">
                        <label style="font-weight: bold;">Deskripsi : </label>
                        <p id="deskripsi">

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $('.mg-zoom').click(function(){
        $.ajax({
            url: "<?php echo e(url('api/galeri')); ?>",
            data: {
                "id": $(this).data('id'),
            },
            success: function (data) {
                $('#myModal').modal('show');
                $('#imgzoom').attr('src', '<?php echo e(asset("galeri")); ?>' + '/' + data.gambar);
                if(data.deskripsi == null || data.deskripsi == ""){
                    $('#deskripsi').html('<i>Tidak ada deskripsi</i>');
                }else{
                    $('#deskripsi').html(data.deskripsi);
                }
                
            }
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kpilogistics\src\resources\views/pages/front/galeri.blade.php ENDPATH**/ ?>